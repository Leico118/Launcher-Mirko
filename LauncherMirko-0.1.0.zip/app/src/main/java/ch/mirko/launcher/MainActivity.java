package ch.mirko.launcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Launcher Mirko — écran d'accueil minimaliste pour la Nvidia Shield.
 * Une liste verticale de grandes cases : on descend avec la télécommande, OK pour ouvrir.
 */
public class MainActivity extends Activity {

    private static final String SETTINGS = "__reglages__";

    // Ordre d'affichage : label, nom du paquet
    private static final String[][] ENTRIES = {
            {"YouTube", "com.google.android.youtube.tv"},
            {"VLC", "org.videolan.vlc"},
            {"Netflix", "com.netflix.ninja"},
            {"Twitch", "tv.twitch.android.app"},
            {"Navigateur", "com.internet.tvbrowser"},
            {"Google Play", "com.android.vending"},
            {"Réglages", SETTINGS},
    };

    private ScrollView scroll;
    private final List<View> tiles = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        focusFirst();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        focusFirst();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        // Écran d'accueil : le bouton retour ne fait rien.
    }

    private void focusFirst() {
        if (tiles.isEmpty()) return;
        scroll.post(() -> {
            scroll.scrollTo(0, 0);
            tiles.get(0).requestFocus();
        });
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }

    private void buildUi() {
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipChildren(false);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setGravity(Gravity.CENTER);
        list.setClipChildren(false);
        list.setClipToPadding(false);
        list.setPadding(0, dp(40), 0, dp(40));
        scroll.addView(list, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        int screenW = getResources().getDisplayMetrics().widthPixels;
        int tileW = (int) (screenW * 0.58f);

        PackageManager pm = getPackageManager();
        for (String[] e : ENTRIES) {
            String label = e[0];
            String pkg = e[1];
            Drawable icon;
            Intent launch;

            if (SETTINGS.equals(pkg)) {
                launch = new Intent(Settings.ACTION_SETTINGS);
                ResolveInfo ri = pm.resolveActivity(launch, 0);
                icon = ri != null ? ri.loadIcon(pm)
                        : getDrawable(android.R.drawable.ic_menu_preferences);
            } else {
                launch = pm.getLeanbackLaunchIntentForPackage(pkg);
                if (launch == null) launch = pm.getLaunchIntentForPackage(pkg);
                if (launch == null) continue; // appli absente : on n'affiche pas la case
                try {
                    icon = pm.getApplicationIcon(pkg);
                } catch (PackageManager.NameNotFoundException ex) {
                    continue;
                }
            }

            View tile = makeTile(label, icon, launch);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tileW, dp(78));
            lp.topMargin = dp(7);
            lp.bottomMargin = dp(7);
            list.addView(tile, lp);
            tiles.add(tile);
        }

        // Navigation : uniquement haut/bas, on ne sort pas de la liste.
        for (int i = 0; i < tiles.size(); i++) {
            View t = tiles.get(i);
            t.setNextFocusLeftId(t.getId());
            t.setNextFocusRightId(t.getId());
            t.setNextFocusUpId(tiles.get(Math.max(0, i - 1)).getId());
            t.setNextFocusDownId(tiles.get(Math.min(tiles.size() - 1, i + 1)).getId());
        }

        setContentView(scroll);
    }

    private View makeTile(String label, Drawable icon, Intent launch) {
        LinearLayout tile = new LinearLayout(this);
        tile.setId(View.generateViewId());
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(22), 0, dp(22), 0);
        tile.setFocusable(true);
        tile.setFocusableInTouchMode(true);
        tile.setClickable(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(18));
        bg.setColor(Color.parseColor("#1A2033"));
        tile.setBackground(bg);

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(icon);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(52), dp(52));
        ilp.rightMargin = dp(22);
        tile.addView(iv, ilp);

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.parseColor("#C9D1E6"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tile.addView(tv);

        tile.setOnFocusChangeListener((v, has) -> {
            if (has) {
                bg.setColor(Color.parseColor("#26365E"));
                bg.setStroke(dp(3), Color.parseColor("#4F8BFF"));
                tv.setTextColor(Color.WHITE);
                v.animate().scaleX(1.05f).scaleY(1.05f).setDuration(120).start();
            } else {
                bg.setColor(Color.parseColor("#1A2033"));
                bg.setStroke(0, Color.TRANSPARENT);
                tv.setTextColor(Color.parseColor("#C9D1E6"));
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            }
        });

        tile.setOnClickListener(v -> {
            try {
                Intent i = new Intent(launch);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (ActivityNotFoundException ex) {
                Toast.makeText(this, label + " introuvable", Toast.LENGTH_SHORT).show();
            }
        });
        return tile;
    }
}
