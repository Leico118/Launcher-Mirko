package ch.mirko.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbAuthException;
import jcifs.smb.SmbFile;

/**
 * Panneau VLC : parcourt le partage \\192.168.0.39\video du NAS Leiko,
 * avec favoris (appui long sur OK) et dernières vidéos lancées.
 */
public class NasPanel extends LinearLayout {

    static final String HOST = "192.168.0.39";
    static final String SHARE = "video";
    private static final String VLC = "org.videolan.vlc";
    private static final Set<String> VIDEO_EXT = new HashSet<>(Arrays.asList(
            "mkv", "mp4", "avi", "mov", "m4v", "wmv", "ts", "m2ts", "webm", "flv",
            "mpg", "mpeg", "vob", "3gp", "divx", "ogv"));

    private final Activity act;
    private final SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final TextView header;
    private final LinearLayout list;
    private final ScrollView scroll;
    private View vlcTile;
    private String path = null;       // chemin relatif affiché ("" = racine)
    private int loadToken = 0;
    private final List<View> rows = new ArrayList<>();

    public NasPanel(Activity a) {
        super(a);
        act = a;
        prefs = a.getSharedPreferences("nas", Context.MODE_PRIVATE);
        setOrientation(VERTICAL);

        header = new TextView(a);
        header.setTextColor(Color.WHITE);
        header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        header.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        header.setSingleLine(true);
        header.setEllipsize(TextUtils.TruncateAt.START);
        addView(header);

        TextView hint = new TextView(a);
        hint.setText("→ pour entrer · OK pour ouvrir · appui long = favori · Retour = dossier parent");
        hint.setTextColor(0x99FFFFFF);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        LayoutParams hp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        hp.topMargin = dp(4);
        hp.bottomMargin = dp(14);
        addView(hint, hp);

        scroll = new ScrollView(a);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(8), dp(8), dp(8), dp(8));
        list = new LinearLayout(a);
        list.setOrientation(VERTICAL);
        scroll.addView(list, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addView(scroll, new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
    }

    void setVlcTile(View t) { vlcTile = t; }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }

    /** Appelé quand la case VLC est sélectionnée. */
    void show() {
        if (path == null) load("");
    }

    boolean hasFocusInside() {
        View f = act.getCurrentFocus();
        return f != null && rows.contains(f);
    }

    /** Bouton Retour dans le panneau : dossier parent, ou retour sur la case VLC. */
    boolean handleBack() {
        if (!hasFocusInside()) return false;
        if (path != null && !path.isEmpty()) {
            int i = path.lastIndexOf('/');
            load(i < 0 ? "" : path.substring(0, i), true);
        } else if (vlcTile != null) {
            vlcTile.requestFocus();
        }
        return true;
    }

    // ---------- Connexion au NAS ----------

    private CIFSContext context() throws Exception {
        Properties p = new Properties();
        p.setProperty("jcifs.smb.client.minVersion", "SMB1");
        p.setProperty("jcifs.smb.client.maxVersion", "SMB311");
        p.setProperty("jcifs.smb.client.responseTimeout", "8000");
        p.setProperty("jcifs.smb.client.soTimeout", "15000");
        p.setProperty("jcifs.resolveOrder", "DNS");
        CIFSContext base = new BaseContext(new PropertyConfiguration(p));
        String user = prefs.getString("user", "");
        if (user.isEmpty()) return base.withGuestCrendentials();
        return base.withCredentials(new NtlmPasswordAuthenticator(
                prefs.getString("domain", ""), user, prefs.getString("pass", "")));
    }

    private static class Entry {
        String name, rel;
        boolean dir;
    }

    private void load(String rel) { load(rel, false); }

    private void load(String rel, boolean focusAfter) {
        path = rel;
        final int token = ++loadToken;
        header.setText(rel.isEmpty() ? "Leiko › vidéo" : "Leiko › " + rel.replace("/", " › "));
        clearRows();
        addInfo("Chargement…");

        io.submit(() -> {
            try {
                String url = "smb://" + HOST + "/" + SHARE + "/" + (rel.isEmpty() ? "" : rel + "/");
                SmbFile dir = new SmbFile(url, context());
                SmbFile[] files = dir.listFiles();
                List<Entry> out = new ArrayList<>();
                for (SmbFile f : files) {
                    String n = f.getName();
                    boolean isDir = n.endsWith("/");
                    if (isDir) n = n.substring(0, n.length() - 1);
                    if (n.startsWith("@") || n.startsWith("#") || n.startsWith(".")) continue;
                    if (!isDir && !VIDEO_EXT.contains(ext(n))) continue;
                    Entry e = new Entry();
                    e.name = n;
                    e.dir = isDir;
                    e.rel = rel.isEmpty() ? n : rel + "/" + n;
                    out.add(e);
                }
                Collections.sort(out, (a, b) -> a.dir != b.dir ? (a.dir ? -1 : 1)
                        : a.name.compareToIgnoreCase(b.name));
                act.runOnUiThread(() -> {
                    if (token == loadToken) showEntries(out, focusAfter);
                });
            } catch (SmbAuthException auth) {
                act.runOnUiThread(() -> {
                    if (token != loadToken) return;
                    clearRows();
                    addInfo("Leiko demande un identifiant.");
                    addAction("Entrer l'identifiant du NAS", () -> askCredentials(rel));
                    wireFocus();
                });
            } catch (Exception ex) {
                act.runOnUiThread(() -> {
                    if (token != loadToken) return;
                    clearRows();
                    addInfo("Impossible de joindre Leiko (" + ex.getClass().getSimpleName()
                            + (ex.getMessage() != null ? " : " + ex.getMessage() : "") + ")");
                    addAction("Réessayer", () -> load(rel, true));
                    addAction("Changer l'identifiant du NAS", () -> askCredentials(rel));
                    wireFocus();
                });
            }
        });
    }

    private static String ext(String n) {
        int i = n.lastIndexOf('.');
        return i < 0 ? "" : n.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private void showEntries(List<Entry> entries, boolean focusAfter) {
        clearRows();
        if (path.isEmpty()) {
            Set<String> favs = prefs.getStringSet("favs", new HashSet<>());
            if (!favs.isEmpty()) {
                addSection("★ Favoris");
                List<String> sorted = new ArrayList<>(favs);
                Collections.sort(sorted, String::compareToIgnoreCase);
                for (String f : sorted) {
                    addRow("★  " + f.replace("/", " › "), true, () -> load(f, true), () -> toggleFav(f));
                }
            }
            List<String> rec = recents();
            if (!rec.isEmpty()) {
                addSection("Récents");
                for (String r : rec) {
                    String name = r.substring(r.lastIndexOf('/') + 1);
                    addRow("▶  " + name, false, () -> play(r), null);
                }
            }
            if (!favs.isEmpty() || !rec.isEmpty()) addSection("Tous les dossiers");
        }
        if (entries.isEmpty()) addInfo("Dossier vide");
        for (Entry e : entries) {
            if (e.dir) {
                boolean fav = prefs.getStringSet("favs", new HashSet<>()).contains(e.rel);
                addRow((fav ? "★  " : "📁  ") + e.name, true, () -> load(e.rel, true),
                        () -> toggleFav(e.rel));
            } else {
                addRow("🎬  " + e.name, false, () -> play(e.rel), null);
            }
        }
        wireFocus();
        if (focusAfter && !rows.isEmpty()) rows.get(0).requestFocus();
        scroll.scrollTo(0, 0);
    }

    // ---------- Lignes de la liste ----------

    private void clearRows() {
        list.removeAllViews();
        rows.clear();
    }

    private void addInfo(String text) {
        TextView tv = new TextView(act);
        tv.setText(text);
        tv.setTextColor(0xBBFFFFFF);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        tv.setPadding(dp(6), dp(10), dp(6), dp(10));
        list.addView(tv);
    }

    private void addSection(String text) {
        TextView tv = new TextView(act);
        tv.setText(text);
        tv.setTextColor(0x99FFFFFF);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tv.setAllCaps(true);
        tv.setPadding(dp(6), dp(14), dp(6), dp(6));
        list.addView(tv);
    }

    private void addAction(String text, Runnable r) {
        addRow("›  " + text, false, r, null);
    }

    private void addRow(String text, boolean dir, Runnable onClick, Runnable onLong) {
        TextView row = new TextView(act);
        row.setId(View.generateViewId());
        row.setText(text);
        row.setTextColor(0xDDFFFFFF);
        row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        row.setSingleLine(true);
        row.setEllipsize(TextUtils.TruncateAt.END);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18), 0, dp(18), 0);
        row.setFocusable(true);
        row.setFocusableInTouchMode(true);
        row.setClickable(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        bg.setColor(0x26FFFFFF);
        row.setBackground(bg);

        row.setOnFocusChangeListener((v, has) -> {
            if (has) {
                bg.setColor(0x59FFFFFF);
                bg.setStroke(dp(3), Color.WHITE);
                row.setTextColor(Color.WHITE);
                v.animate().scaleX(1.02f).scaleY(1.02f).setDuration(100).start();
            } else {
                bg.setColor(0x26FFFFFF);
                bg.setStroke(0, Color.TRANSPARENT);
                row.setTextColor(0xDDFFFFFF);
                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
            }
        });
        row.setOnClickListener(v -> onClick.run());
        if (onLong != null) {
            row.setOnLongClickListener(v -> {
                onLong.run();
                return true;
            });
        }

        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, dp(54));
        lp.topMargin = dp(5);
        lp.bottomMargin = dp(5);
        list.addView(row, lp);
        rows.add(row);
    }

    /** Gauche = retour sur la case VLC ; la case VLC → droite = première ligne. */
    private void wireFocus() {
        if (vlcTile == null) return;
        if (rows.isEmpty()) {
            vlcTile.setNextFocusRightId(vlcTile.getId());
            return;
        }
        vlcTile.setNextFocusRightId(rows.get(0).getId());
        for (int i = 0; i < rows.size(); i++) {
            View r = rows.get(i);
            r.setNextFocusLeftId(vlcTile.getId());
            r.setNextFocusRightId(r.getId());
            r.setNextFocusUpId(rows.get(Math.max(0, i - 1)).getId());
            r.setNextFocusDownId(rows.get(Math.min(rows.size() - 1, i + 1)).getId());
        }
    }

    // ---------- Favoris, récents, lecture ----------

    private void toggleFav(String rel) {
        Set<String> favs = new HashSet<>(prefs.getStringSet("favs", new HashSet<>()));
        boolean added;
        if (favs.contains(rel)) {
            favs.remove(rel);
            added = false;
        } else {
            favs.add(rel);
            added = true;
        }
        prefs.edit().putStringSet("favs", favs).apply();
        Toast.makeText(act, (added ? "Ajouté aux favoris : " : "Retiré des favoris : ") + rel,
                Toast.LENGTH_SHORT).show();
        load(path, true);
    }

    private List<String> recents() {
        String raw = prefs.getString("recents", "");
        List<String> out = new ArrayList<>();
        for (String s : raw.split("\n")) if (!s.isEmpty()) out.add(s);
        return out;
    }

    private void addRecent(String rel) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        set.add(rel);
        set.addAll(recents());
        List<String> list = new ArrayList<>(set);
        if (list.size() > 5) list = list.subList(0, 5);
        prefs.edit().putString("recents", TextUtils.join("\n", list)).apply();
    }

    private void play(String rel) {
        addRecent(rel);
        StringBuilder sb = new StringBuilder("smb://");
        String user = prefs.getString("user", "");
        if (!user.isEmpty()) {
            sb.append(Uri.encode(user)).append(':')
                    .append(Uri.encode(prefs.getString("pass", ""))).append('@');
        }
        sb.append(HOST).append('/').append(SHARE);
        for (String part : rel.split("/")) sb.append('/').append(Uri.encode(part));

        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setPackage(VLC);
        i.setDataAndType(Uri.parse(sb.toString()), "video/*");
        i.putExtra("title", rel.substring(rel.lastIndexOf('/') + 1));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            act.startActivity(i);
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(act, "VLC introuvable", Toast.LENGTH_SHORT).show();
        }
    }

    private void askCredentials(String retryRel) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(VERTICAL);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        EditText user = new EditText(act);
        user.setHint("Nom d'utilisateur");
        user.setInputType(InputType.TYPE_CLASS_TEXT);
        user.setText(prefs.getString("user", ""));
        EditText pass = new EditText(act);
        pass.setHint("Mot de passe");
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(user);
        box.addView(pass);
        new AlertDialog.Builder(act)
                .setTitle("Identifiant du NAS Leiko")
                .setView(box)
                .setPositiveButton("OK", (d, w) -> {
                    prefs.edit()
                            .putString("user", user.getText().toString().trim())
                            .putString("pass", pass.getText().toString())
                            .apply();
                    load(retryRel, true);
                })
                .setNegativeButton("Annuler", null)
                .show();
    }
}
