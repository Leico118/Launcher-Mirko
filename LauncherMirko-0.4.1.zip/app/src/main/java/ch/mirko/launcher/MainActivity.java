package ch.mirko.launcher;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Launcher Mirko 0.4 — accueil façon console : colonne de grandes cases à gauche,
 * grande zone d'ambiance à droite qui change selon l'appli sélectionnée.
 */
public class MainActivity extends Activity {

    private static final String SETTINGS = "__reglages__";

    // label, paquet, couleur principale, sous-titre
    private static final String[][] ENTRIES = {
            {"YouTube", "com.google.android.youtube.tv", "#FF0033", "Vidéos, musique et chaînes"},
            {"VLC", "org.videolan.vlc", "#FF8800", "Tes vidéos du NAS Leiko"},
            {"Netflix", "com.netflix.ninja", "#E50914", "Films et séries"},
            {"Twitch", "tv.twitch.android.app", "#9146FF", "Streams en direct"},
            {"Navigateur", "com.internet.tvbrowser", "#1E88E5", "Naviguer sur le web"},
            {"Google Play", "com.android.vending", "#01875F", "Installer des applis et des jeux"},
            {"Réglages", SETTINGS, "#607D8B", "Paramètres de la Shield"},
    };

    private static class App {
        String label, subtitle;
        int color, tileColor;
        Drawable icon, banner;
        Bitmap blurred;
        Intent launch;
        View tile;
    }

    private static final int TILE_W = 290;
    private static final int TILE_H = 116;

    private int TILE_W_DP_PX() { return dp(TILE_W); }

    private final List<App> apps = new ArrayList<>();
    private ImageView bgA, bgB;
    private boolean bgAOnTop = true;
    private View colorWash;
    private GradientDrawable washDrawable;
    private int currentColor = Color.BLACK;
    private TextView title, subtitle;
    private ImageView bannerView;
    private LinearLayout infoBlock;
    private NasPanel nasPanel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadApps();
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (getCurrentFocus() == null) focusFirst();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        focusFirst();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        // Écran d'accueil : Retour ne sert qu'à remonter dans les dossiers du NAS.
        if (nasPanel != null) nasPanel.handleBack();
    }

    private void focusFirst() {
        if (apps.isEmpty()) return;
        apps.get(0).tile.post(() -> apps.get(0).tile.requestFocus());
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }

    // ---------- Chargement des applis ----------

    private void loadApps() {
        PackageManager pm = getPackageManager();
        for (String[] e : ENTRIES) {
            App a = new App();
            a.label = e[0];
            a.color = Color.parseColor(e[2]);
            a.subtitle = e[3];
            String pkg = e[1];

            if (SETTINGS.equals(pkg)) {
                a.launch = new Intent(Settings.ACTION_SETTINGS);
                ResolveInfo ri = pm.resolveActivity(a.launch, 0);
                a.icon = ri != null ? ri.loadIcon(pm)
                        : getDrawable(android.R.drawable.ic_menu_preferences);
            } else {
                a.launch = pm.getLeanbackLaunchIntentForPackage(pkg);
                if (a.launch == null) a.launch = pm.getLaunchIntentForPackage(pkg);
                if (a.launch == null) continue;
                try {
                    a.icon = pm.getApplicationIcon(pkg);
                    a.banner = pm.getApplicationBanner(pkg);
                    if (a.banner == null) a.banner = pm.getActivityBanner(a.launch);
                } catch (Exception ex) {
                    continue;
                }
            }
            Drawable src = a.banner != null ? a.banner : a.icon;
            a.blurred = blur(src);
            a.tileColor = a.banner != null ? cornerColor(a.banner, a.color) : a.color;
            apps.add(a);
        }
    }

    /** Flou très léger en calcul : on réduit l'image à quelques pixels, l'agrandissement lisse le reste. */
    private Bitmap blur(Drawable d) {
        if (d == null) return null;
        try {
            int w = Math.max(1, d.getIntrinsicWidth() > 0 ? d.getIntrinsicWidth() : 320);
            int h = Math.max(1, d.getIntrinsicHeight() > 0 ? d.getIntrinsicHeight() : 180);
            Bitmap full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(full);
            d.setBounds(0, 0, w, h);
            d.draw(c);
            Bitmap small = Bitmap.createScaledBitmap(full, 16, 9, true);
            full.recycle();
            return small;
        } catch (Exception ex) {
            return null;
        }
    }

    /** Couleur du coin de la bannière, pour que la case se fonde avec l'image. */
    private int cornerColor(Drawable d, int fallback) {
        try {
            int w = d.getIntrinsicWidth() > 0 ? d.getIntrinsicWidth() : 320;
            int h = d.getIntrinsicHeight() > 0 ? d.getIntrinsicHeight() : 180;
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            d.setBounds(0, 0, w, h);
            d.draw(new Canvas(b));
            int c = b.getPixel(3, 3);
            b.recycle();
            return Color.alpha(c) < 200 ? fallback : c;
        } catch (Exception ex) {
            return fallback;
        }
    }

    // ---------- Interface ----------

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        // 1. Deux couches d'arrière-plan flou pour les fondus enchaînés
        bgA = makeBg();
        bgB = makeBg();
        root.addView(bgA, match());
        root.addView(bgB, match());

        // 2. Voile de couleur de l'appli
        colorWash = new View(this);
        washDrawable = new GradientDrawable(GradientDrawable.Orientation.TR_BL,
                new int[]{Color.TRANSPARENT, Color.TRANSPARENT});
        colorWash.setBackground(washDrawable);
        root.addView(colorWash, match());

        // 3. Assombrissement à gauche et en bas pour la lisibilité
        View shadeLeft = new View(this);
        shadeLeft.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xF2000000, 0x99000000, 0x22000000}));
        root.addView(shadeLeft, match());
        View shadeBottom = new View(this);
        shadeBottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xCC000000, 0x00000000}));
        root.addView(shadeBottom, match());

        // 4. Horloge en haut à droite
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        clp.topMargin = dp(28);
        clp.rightMargin = dp(40);
        root.addView(clock, clp);

        // 5. Colonne de grandes cases à gauche (défilante)
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipChildren(false);
        scroll.setClipToPadding(false);
        scroll.setSmoothScrollingEnabled(true);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setClipChildren(false);
        column.setClipToPadding(false);
        column.setPadding(dp(36), dp(40), dp(24), dp(40));
        scroll.addView(column, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout.LayoutParams colp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.START);
        root.addView(scroll, colp);
        root.setClipChildren(false);

        for (App a : apps) {
            a.tile = makeIconTile(a);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(TILE_W_DP_PX(), dp(TILE_H));
            lp.topMargin = dp(7);
            lp.bottomMargin = dp(7);
            column.addView(a.tile, lp);
        }
        for (int i = 0; i < apps.size(); i++) {
            View t = apps.get(i).tile;
            t.setNextFocusLeftId(t.getId());
            t.setNextFocusRightId(t.getId());
            t.setNextFocusUpId(apps.get(Math.max(0, i - 1)).tile.getId());
            t.setNextFocusDownId(apps.get(Math.min(apps.size() - 1, i + 1)).tile.getId());
        }

        // 6. Bloc d'infos à droite de la colonne
        infoBlock = new LinearLayout(this);
        infoBlock.setOrientation(LinearLayout.VERTICAL);
        infoBlock.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.START);
        ilp.leftMargin = dp(36 + TILE_W + 70);
        ilp.rightMargin = dp(48);
        root.addView(infoBlock, ilp);

        bannerView = new ImageView(this);
        bannerView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        bannerView.setClipToOutline(true);
        GradientDrawable bannerShape = new GradientDrawable();
        bannerShape.setCornerRadius(dp(14));
        bannerView.setBackground(bannerShape);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(96), dp(96));
        blp.bottomMargin = dp(22);
        infoBlock.addView(bannerView, blp);

        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 52);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setSingleLine(true);
        infoBlock.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        subtitle = new TextView(this);
        subtitle.setTextColor(0xCCFFFFFF);
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        subtitle.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(4);
        infoBlock.addView(subtitle, slp);

        TextView hint = new TextView(this);
        hint.setText("OK pour ouvrir");
        hint.setTextColor(0x88FFFFFF);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = dp(26);
        infoBlock.addView(hint, hlp);

        // 7. Panneau VLC (dossiers du NAS), à la place du bloc d'infos
        nasPanel = new NasPanel(this);
        nasPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        nlp.leftMargin = dp(36 + TILE_W + 70);
        nlp.rightMargin = dp(48);
        nlp.topMargin = dp(70);
        nlp.bottomMargin = dp(36);
        root.addView(nasPanel, nlp);
        for (App a : apps) if ("VLC".equals(a.label)) nasPanel.setVlcTile(a.tile);
        nasPanel.preload();

        setContentView(root);
        startSlowZoom(bgA);
        startSlowZoom(bgB);
    }

    private FrameLayout.LayoutParams match() {
        return new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private ImageView makeBg() {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setAlpha(0f);
        return iv;
    }

    /** Zoom lent et continu sur le fond, pour que l'écran « vive ». */
    private void startSlowZoom(View v) {
        ValueAnimator an = ValueAnimator.ofFloat(1.0f, 1.12f);
        an.setDuration(18000);
        an.setRepeatMode(ValueAnimator.REVERSE);
        an.setRepeatCount(ValueAnimator.INFINITE);
        an.addUpdateListener(x -> {
            float s = (float) x.getAnimatedValue();
            v.setScaleX(s);
            v.setScaleY(s);
        });
        an.start();
    }

    private View makeIconTile(App a) {
        FrameLayout tile = new FrameLayout(this);
        tile.setId(View.generateViewId());
        tile.setFocusable(true);
        tile.setFocusableInTouchMode(true);
        tile.setClickable(true);
        tile.setClipToOutline(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(a.tileColor);
        tile.setBackground(bg);
        tile.setAlpha(0.6f);

        ImageView iv = new ImageView(this);
        if (a.banner != null) {
            iv.setImageDrawable(a.banner);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            tile.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            // Pas de bannière officielle : icône + nom
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            iv.setImageDrawable(a.icon);
            row.addView(iv, new LinearLayout.LayoutParams(dp(56), dp(56)));
            TextView tv = new TextView(this);
            tv.setText(a.label);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            tv.setPadding(dp(16), 0, 0, 0);
            row.addView(tv);
            tile.addView(row, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        // Cadre blanc de sélection, posé par-dessus l'image
        View frame = new View(this);
        GradientDrawable fr = new GradientDrawable();
        fr.setCornerRadius(dp(16));
        fr.setColor(Color.TRANSPARENT);
        frame.setBackground(fr);
        tile.addView(frame, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        tile.setOnFocusChangeListener((v, has) -> {
            if (has) {
                fr.setStroke(dp(4), Color.WHITE);
                v.animate().scaleX(1.06f).scaleY(1.06f).alpha(1f).setDuration(160)
                        .setInterpolator(new DecelerateInterpolator()).start();
                showApp(a);
            } else {
                fr.setStroke(0, Color.TRANSPARENT);
                v.animate().scaleX(1f).scaleY(1f).alpha(0.6f).setDuration(160).start();
            }
        });

        tile.setOnClickListener(v -> {
            try {
                Intent i = new Intent(a.launch);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (ActivityNotFoundException ex) {
                Toast.makeText(this, a.label + " introuvable", Toast.LENGTH_SHORT).show();
            }
        });
        return tile;
    }

    /** Met à jour la zone de droite : fond flou, couleur, bannière et textes. */
    private void showApp(App a) {
        // Fond : fondu enchaîné entre les deux couches
        ImageView incoming = bgAOnTop ? bgB : bgA;
        ImageView outgoing = bgAOnTop ? bgA : bgB;
        if (a.blurred != null) {
            BitmapDrawable bd = new BitmapDrawable(getResources(), a.blurred);
            bd.setFilterBitmap(true);
            incoming.setImageDrawable(bd);
        } else {
            incoming.setImageDrawable(null);
        }
        // La nouvelle couche passe au-dessus de l'ancienne, sous tout le reste
        ViewGroup root = (ViewGroup) incoming.getParent();
        root.removeView(incoming);
        root.addView(incoming, 0);
        root.removeView(outgoing);
        root.addView(outgoing, 0);
        incoming.animate().alpha(0.9f).setDuration(450).start();
        outgoing.animate().alpha(0f).setDuration(450).start();
        bgAOnTop = !bgAOnTop;

        // Voile coloré qui glisse vers la couleur de l'appli
        int from = currentColor;
        int to = a.color;
        ValueAnimator ca = ValueAnimator.ofArgb(from, to);
        ca.setDuration(450);
        ca.addUpdateListener(x -> {
            int c = (int) x.getAnimatedValue();
            washDrawable.setColors(new int[]{(c & 0x00FFFFFF) | 0x99000000,
                    (c & 0x00FFFFFF) | 0x22000000});
        });
        ca.start();
        currentColor = to;

        // Bannière et textes
        bannerView.setImageDrawable(a.icon);
        boolean vlc = "VLC".equals(a.label);
        nasPanel.setVisibility(vlc ? View.VISIBLE : View.GONE);
        infoBlock.setVisibility(vlc ? View.GONE : View.VISIBLE);
        if (vlc) {
            nasPanel.show();
            return;
        }
        title.setText(a.label);
        subtitle.setText(a.subtitle);
        infoBlock.setAlpha(0f);
        infoBlock.setTranslationX(dp(24));
        infoBlock.animate().alpha(1f).translationX(0).setDuration(300)
                .setInterpolator(new DecelerateInterpolator()).start();
    }
}
